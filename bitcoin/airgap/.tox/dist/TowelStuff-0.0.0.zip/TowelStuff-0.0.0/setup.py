from distutils.core import setup

setup(name='TowelStuff',
      install_requires=['future', 'cryptography', 'pycoin'])
